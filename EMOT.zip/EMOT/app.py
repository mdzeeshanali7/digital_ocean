import random
import smtplib
from flask import Flask, render_template, request, redirect, url_for, session, flash
from pymongo import MongoClient
import bcrypt
import utils
import base64
from flask import jsonify

app = Flask(__name__)
app.secret_key = "qwertyui123456"

# MongoDB connection
try:
    client = MongoClient("mongodb+srv://shreydutta2024:1234567890@cluster0.f9ejp.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0")
    db = client['EmailBot_data']
    user_collection = db["userData"]
except Exception as e:
    print("Error connecting to MongoDB:", e)

@app.route('/', methods=['POST', 'GET'])
def signup():
    if request.method == 'POST':
        name = request.form.get('name')
        email = request.form.get('email')
        phone_number = request.form.get('phone_number')
        password = request.form.get('password')
        user_ip = request.remote_addr

        existingUser  = user_collection.find_one({"email": email})
        if existingUser :
            flash(f'Welcome back {email}!', 'success')
            existingUser ['_id'] = str(existingUser ['_id'])
            session['userData'] = {**existingUser , 'ip': user_ip}
            return redirect(url_for('choose_plan'))

        # Hash the password before storing
        hashed_password = bcrypt.hashpw(password.encode('utf-8'), bcrypt.gensalt())
        otp = random.randint(100000, 999999)

        session['userData'] = {
            'name': name,
            'email': email,
            'phone_number': phone_number,
            'password': hashed_password,
            'ip': user_ip,
            "otp": otp
        }

        if not utils.send_otp_via_smtp(to_email=email, otp=otp):
            flash("Failed to send OTP", 'error')
        else:
            flash("OTP sent successfully", 'success')
            return redirect(url_for('verify_otp'))
    return render_template('registration.html')

@app.route('/login', methods=['POST', 'GET'])
def login():
    if request.method == 'POST':
        email = request.form.get('email')
        password = request.form.get('password')
        existingUser  = user_collection.find_one({'email': email})

        if existingUser  and bcrypt.checkpw(password.encode('utf-8'), existingUser ['password']):
            existingUser ['_id'] = str(existingUser ['_id'])
            session['userData'] = {**existingUser }
            flash(f'Welcome back {email}!', 'success')
            return redirect(url_for('choose_plan'))
        else:
            flash('Wrong email or password', 'error')
    return render_template('login.html')

@app.route('/logout')
def logout():
    session.clear()
    return redirect(url_for('login'))

@app.route('/verify_otp', methods=['POST', 'GET'])
def verify_otp():
    if request.method == 'POST':
        otp = request.form.get('otp')
        user_data = session.get('userData')

        if otp == str(user_data['otp']):
            data = {
                "name": user_data["name"],
                "email": user_data["email"],
                "phone_number": user_data["phone_number"],
                "password": user_data["password"],  # Store hashed password
                "ip": user_data['ip']
            }
            user_collection.insert_one(data)
            flash("User  registered successfully", 'success')
            return redirect(url_for('free_trial'))
        else:
            flash("OTP does not match", 'error')

    return render_template('verify.html')

@app.route('/forgot', methods=['POST', 'GET'])
def forgot():
    if request.method == 'POST':
        email = request.form.get('email')
        phone = request.form.get('phone')
        exists = user_collection.find_one({"email": email})

        if exists:
            otp = random.randint(100000, 999999)
            session['passwordchange'] = {
                "email": email,
                "otp": otp
            }
            if not utils.send_otp_via_smtp(to_email=email, otp=otp):
                flash("Failed to send OTP", 'error')
            else:
                flash("OTP sent successfully", 'success')
                return redirect(url_for('forgot_verify'))
        else:
            flash("Email not found", 'error')
    return render_template("forgot.html")

@app.route('/forgot_verify', methods=['POST', 'GET'])
def forgot_verify():
    if request.method == 'POST':
        otp = request.form.get('otp')
        user_data = session.get('passwordchange')

        if otp == str(user_data['otp']):
            return redirect(url_for('change_password'))
        else:
            flash("OTP does not match", 'error')
    return render_template('forgot_verify.html')

@app.route('/change_password', methods=['POST', 'GET'])
def change_password():
    if request.method == 'POST':
        password = request.form.get('password')
        confirm_password = request.form.get('confirm_password')
        user_data = session.get('passwordchange')

        if password == confirm_password:
            hashed_password = bcrypt.hashpw(password.encode('utf-8'), bcrypt.gensalt())
            user_collection.update_one({"email": user_data['email']}, {"$set": {"password": hashed_password}})
            flash("Password updated successfully", 'success')
            return redirect(url_for('login'))
        else:
            flash("Passwords do not match", 'error')
    return render_template('change_password.html')

@app.route('/plan_selection', methods=['POST'])
def plan_selection():
    data = request.get_json()

    # Check if data is received and contains 'plan'
    if data is None or 'plan' not in data:
        return jsonify({"error": "No data received"}), 400

    plan = data['plan']
    session['selectedplan'] = {"plan": plan}
    print("Selected Plan:", session['selectedplan'])  # Debugging line

    flash('Congratulations! Plan selected successfully!', 'success')

    return jsonify({"message": "Plan selected successfully!", "redirect": url_for('cart')}), 200
    # return "Redirecting to cart..."  # Temporary debug line
    # return redirect(url_for('cart'))

@app.route('/cart', methods=['POST', 'GET'])
def cart():
    return render_template('cart.html')
    # return "This is the cart page."

@app.route('/payment_selection', methods=['POST'])
def payment_selection():
    data = request.get_json()

    # Check if data is received and contains 'plan'
    if data is None or 'plan' not in data:
        return jsonify({"error": "No data received"}), 400

    plan = data['plan']
    session['selectedplan'] = {"plan": plan}
    print("Selected Plan:", session['selectedplan'])  # Debugging line

    flash('Ready to Checkout!', 'success')

    return jsonify({"message": "Proceed for Payment!", "redirect": url_for('payment')}), 200

@app.route('/payment', methods=['POST', 'GET'])
def payment():
    return render_template('payment.html')

@app.route('/free_trial', methods=['POST', 'GET'])
def free_trial():
    return render_template('free-trial.html')

@app.route('/choose_plan', methods=['POST', 'GET'])
def choose_plan():
    if request.method == 'POST':
        transactionNumber = request.form.get('transacrtionNumber')
        paymentScreenshot = request.files.get('paymentScreenshot')
        user_data = session.get('userData')
        selectedPlan = session.get('selectedplan')

        if transactionNumber:
            user_collection.update_one({"email": user_data['email']}, {"$set": {"plan": selectedPlan['plan'], 'transactionNumber': transactionNumber}})
            flash('Plan Updated', 'success')
        elif paymentScreenshot:
            encodedString = base64.b64encode(paymentScreenshot.read()).decode('utf-8')
            # Store or process the encoded string as needed

    return render_template('choose-plans.html')

@app.route('/test')
def test():
    return render_template('choose-plans.html')

if __name__ == '__main__':
    app.run(debug=True)
