import random
import smtplib
from flask import Flask, render_template, request,redirect,url_for
from pymongo import MongoClient
import json
from flask import session
import base64
import re

app = Flask(__name__)
app.secret_key = "qwertyui123456"
try:
    client = MongoClient("mongodb+srv://shreydutta2024:1234567890@cluster0.f9ejp.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0")
    db = client['EmailBot_data']
    user_collection = db["userData"]
except Exception as e:
    print("Error connecting to MongoDB:", e)


def send_otp_via_smtp(to_email, otp):
    try:
        smtp_server = "smtp.gmail.com"
        smtp_port = 587
        sender_email = "farid747870@gmail.com"
        sender_password = "eysz ytht jizb yfmt"

        with smtplib.SMTP(smtp_server, smtp_port) as server:
            server.starttls()
            server.login(sender_email, sender_password)
            message = f"Subject: Verify Your Account\n\nYour OTP is: {otp}"
            server.sendmail(sender_email, to_email, message)
        print("Email sent successfully inside function")
    except Exception as e:
        print("Error sending email:", e)
        return False
    return True

def send_download_link(to_email, plan,link,activation_code):
    try:
        smtp_server = "smtp.gmail.com"
        smtp_port = 587
        sender_email = "farid747870@gmail.com"
        sender_password = "eysz ytht jizb yfmt"

        with smtplib.SMTP(smtp_server, smtp_port) as server:
            server.starttls()
            server.login(sender_email, sender_password)
            subject = f"You have selected the {plan} plan"
            body = f"Here is your download link: {link} and your activation code : {activation_code}"
            message = f"Subject: {subject}\n\n{body}"            
            server.sendmail(sender_email, to_email, message)
    except Exception as e:
        print("Error sending email:", e)
        return False
    return True

def generate_activation_code():
    import random
    import string
    activation_code = ''.join(random.choices(string.ascii_uppercase + string.digits, k=16)) 
    return activation_code
def update_user_activation_code(email, activation_code, plan):
    from datetime import datetime
    timestamp = datetime.now().strftime("%Y-%m-%d")
    user_data = user_collection.find_one({"email": email})
    user_collection.update_one({"email": email}, {"$set": {"ActivationKey": activation_code, "plan": plan, "TimeStamp": timestamp}})
    print("Activation code, plan, and timestamp updated successfully.")
    
#End Util Functions   
